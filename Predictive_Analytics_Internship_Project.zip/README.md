# Predictive Analytics Using Historical Data

This project builds a predictive model to forecast future sales trends using historical data.

## Key Features
- Cleans and preprocesses historical sales data
- Uses Linear Regression for prediction
- Evaluates model accuracy using R² Score and Mean Absolute Error
- Forecasts sales for 2026–2030
- Visualizes historical data and future predictions

## Technologies Used
Python, Pandas, Matplotlib, Scikit-learn

## Files
- `historical_sales.csv` — historical dataset
- `predictive_model.py` — Python prediction model
- `future_predictions.csv` — generated forecasts
- `prediction_chart.png` — visualization

## How to Run
Install dependencies:
`pip install pandas matplotlib scikit-learn`

Then run:
`python predictive_model.py`
