import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

data = pd.read_csv("historical_sales.csv")
X = data[["Year"]]
y = data["Sales"]

model = LinearRegression()
model.fit(X, y)

training_predictions = model.predict(X)
print("R2 Score:", r2_score(y, training_predictions))
print("MAE:", mean_absolute_error(y, training_predictions))

future = pd.DataFrame({"Year": range(2026, 2031)})
future["Predicted_Sales"] = model.predict(future[["Year"]])
future.to_csv("future_predictions.csv", index=False)
print(future)

plt.plot(data["Year"], data["Sales"], marker="o", label="Historical Sales")
plt.plot(future["Year"], future["Predicted_Sales"], marker="o", linestyle="--", label="Forecast")
plt.xlabel("Year")
plt.ylabel("Sales")
plt.title("Predictive Analytics Using Historical Data")
plt.legend()
plt.show()
