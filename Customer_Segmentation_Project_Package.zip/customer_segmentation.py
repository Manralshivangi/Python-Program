import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
df=pd.read_csv('customer_data.csv')
X=df[['Income','SpendingScore']]
kmeans=KMeans(n_clusters=4,random_state=42,n_init=10)
df['Cluster']=kmeans.fit_predict(X)
plt.scatter(df['Income'],df['SpendingScore'],c=df['Cluster'])
plt.xlabel('Income'); plt.ylabel('SpendingScore')
plt.show()
print(df.head())
